@extends('layouts.main')

@section('container')
<div class="container">

<div class="row align-items-center ">
  <div>
    <br>
    <h1 class="font-weight-light">What is Ultraman?</h1>
    <p>Ultraman, also known as the Ultra Series (Japanese: ウルトラシリーズ, Hepburn: Urutora Shirīzu), is the collective name for all media produced by Tsuburaya Productions featuring Ultraman, his many brethren, and the myriad Ultra Monsters. Debuting with Ultra Q and then Ultraman in 1966, the Ultra Series is one of the most prominent tokusatsu superhero genre productions from Japan. The Ultra Series is also one of the most well-known examples of the daikaiju / giant monster genre. However, the Ultra Series also falls into the kyodai hīro / 'giant hero' subgenre of tokusatsu TV shows.</p>
  </div>
</div>

<div class="card text-white bg-secondary my-5 py-4 text-center">
  <div class="card-body">
    <h4 class="text-white m-0">"Human beings can become a light all on their own."</h4>
  </div>
</div>

</div>



<div style="background-color: #e4e5e9;">

<!-- video -->  
<br>
<br>
<div class="bg-dark background">
<br>
<h1 class="text-white relative">VIDEOS</h1>
<br>
</div>
<br><br>

<div class="container">
<div>
<iframe width="1100" height="600" src="https://www.youtube.com/embed/1cdYzHEFHuM"allowfullscreen frameborder="0">
</iframe>
</div>
<div>
<iframe width="400" height="400" src="https://www.youtube.com/embed/svvhY8CqnU4"allowfullscreen frameborder="0">
</iframe>
<iframe width="696" height="400" src="https://www.youtube.com/embed/rN_rnVVq7Vs"allowfullscreen frameborder="0">
</iframe>
</div>
<div>
<iframe width="1100" height="600" src="https://www.youtube.com/embed/4WV83SGqBL0"allowfullscreen frameborder="0">
</iframe>
</div><br>
</div>
<br><br>


<!-- other --> 
<br>
<div class="bg-dark background">
<br>
<h1 class="text-white relative">OTHERS</h1>
<br>
</div>
<br><br>

<div class="container">
<div class="row">

<div class="col-md-4 mb-5">
<div class="cardd" style="background-color: white;">
<img src="img/ultraheroes.png" style="width:100%">
<div class="containerr">
<h4><b>Ultra Heroes</b></h4> 
<p>Find out more about The Ultra Heroes</p> 
</div>
<div class="card-footer">
<a href="/about" class="btn btn-primary btn-sm">More Info</a>
</div>
</div>
</div>


<div class="col-md-4 mb-5">
<div class="cardd" style="background-color: white;">
<img src="img/customultra.png" style="width:100%">
<div class="containerr">
<h4><b>Character Creation</b></h4> 
<p>Create your own Character</p> 
</div>
<div class="card-footer">
<a href="/blog" class="btn btn-primary btn-sm">More Info</a>
</div>
</div>
</div>

<div class="col-md-4 mb-5">
<div class="cardd" style="background-color: white;">
<img src="img/customlist.png" style="width:100%">
<div class="containerr">
<h4><b>Custom Character List</b></h4> 
<p>List of Custom Characters</p> 
</div>
<div class="card-footer">
<a href="/blog" class="btn btn-primary btn-sm">More Info</a>
</div>
</div>
</div>

</div>
</div>
<br>

</div>
@endsection