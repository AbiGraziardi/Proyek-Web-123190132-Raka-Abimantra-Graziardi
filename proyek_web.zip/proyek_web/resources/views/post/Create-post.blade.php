@extends('layouts.main')

@section('container')
    
<br><br>
<div class="bg-dark background">
  <br>
  <h1 class="text-white relative">CREATION</h1>
  <br>
</div>
<br><br><br>

<div class="container" style="padding: 0px 20px;">
<div class="borderr center" style="width:50%; background-color: white;">
<div class="container" style="padding: 0px 20px;">
  <div>
    <br>
    <h4 class="text-center">Fill In Your Information</h4>
    <br>

  <table class="center" style="width:50%">
	<form method="POST" action="">
    <tr>
		<td style="margin: 10px;"><h5 class="text-dark"> Name </h5></td>
    </tr>
    <tr>
    <td><input type="text" id="name" name="name" size="65" placeholder="Name (e.g.,Alien Baltan)"></td>
    </tr><td class="td"></td>
 
    <tr>
    <td style="margin: 10px;"><h5 class="text-dark"> Origin </h5></td>
    </tr>
    <tr>
    <td><input type="text" id="origin" name="origin" size="65" placeholder="(e.g.,Earth)"></td>
    </tr><td class="td"></td>

    <tr>
    <td style="margin: 10px;"><h5 class="text-dark"> Primary Color </h5></td>
    </tr>
    <tr>
    <td><input type="text" id="primary_color" name="primary_color" size="65" placeholder="(e.g.,Red)"></td>
    </tr><td class="td"></td>

    <tr>
    <td style="margin: 10px;"><h5 class="text-dark"> Secondary Color </h5></td>
    </tr>
    <tr>
    <td><input type="text" id="secondary_color" name="secondary_color" size="65" placeholder="(e.g.,Green)"></td>
    </tr><td class="td"></td>

    <tr>
    <td style="margin: 10px;"><h5 class="text-dark"> Finisher </h5></td>
    </tr>
    <tr>
    <td><input type="text" id="finisher" name="finisher" size="65" placeholder="(e.g.,Specium Beam)"></td>
    </tr><td class="td"></td>

    <tr>
    <td style="margin: 10px;"><h5 class="text-dark"> Race </h5></td>
    </tr>
    <tr>
    <td>
      <select class="combo" id="race" name="race">
      <option value="Ultra">Ultra</option>
      <option value="Alien">Alien</option>
      <option value="Kaiju">Kaiju</option>
      <option value="Mecha">Mecha</option>
      <option value="Human">Human</option>
      <option value="Undefined">Undefined</option>
      </select>      
    </td>
    </tr><td class="td"></td>

    <tr>
    <td style="margin: 10px;"><h5 class="text-dark"> Type </h5></td>
    </tr>
    <tr>
    <td>
      <select class="combo" id="type" name="type">
      <option value="Undefined">-</option>
      <option value="Hero">Hero</option>
      <option value="Villain">Villain</option>
      <option value="Antihero">Antihero</option>
      </select>      
    </td>
    </tr><td class="td"></td>

    <tr>
    <td style="margin: 10px;"><h5 class="text-dark"> Gender </h5></td>
    </tr>
    <tr>
      <td>
        <input style="margin: 0 5px 0 0px;"type="radio" value="Male" id="gender" name="gender" >Male
        <input style="margin: 0 5px 0 20px;"type="radio" value="Female" id="gender" name="gender">Female
        <input style="margin: 0 5px 0 20px;"type="radio" value="Other"  id="gender" name="gender">Other
      </td>
    </tr><td class="td"></td>

		<tr>
    <td><button type="submit" class="btn btn-success">Create Character</button></td>
    </tr>
    <tr>
    </tr><td class="td"></td>
	</form>
  </table>

  </div>
</div>
</div>
</div>
<br><br>

@endsection

