<?php

use App\Models\Post;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PostController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('home',[
        "title" => "Home"
    ]);
});

Route::get('/about', function () {
    return view('about', [
        "title" => "About"
    ]);
});



Route::get('/data-post',[PostController::class, 'index'])-> name("data-post");
Route::get('/create-post',[PostController::class, 'create'])-> name("create-post");
Route::get('/save-post',[PostController::class, 'store'])-> name("save-post");
Route::get('/edit-post/{id}', [ArtikelController::class, 'edit'])->name('edit-post');
Route::post('/update-post/{id}', [ArtikelController::class, 'update'])->name('update-post');
Route::get('/delete-post/{id}', [ArtikelController::class, 'destroy'])->name('delete-post');