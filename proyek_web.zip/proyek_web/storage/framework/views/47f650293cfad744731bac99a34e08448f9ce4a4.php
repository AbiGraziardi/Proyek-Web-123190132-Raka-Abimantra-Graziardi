

<?php $__env->startSection('container'); ?>
    
<div style="background-color: #e4e5e9;">


<br><br>
<div class="bg-dark background">
  <br>
  <h1 class="text-white relative">CUSTOM RIDERS</h1>
  <br>
</div>
<br><br>


		<div class="container" style="padding: 0px 40px;">

		<div class="borderr center" style="width:50%; background-color: white;">
		<br>
		<h2 style="height:50px;" class="pl-4"> Kamen Rider .....</h2>
		<br></br>
		<h3 class="relative2">Data</h3>

		<table class="center" style="width:70%">
			
				<tr>
				<td style="height:50px" class="pl-4"> Origin </td>
				<td class="pl-3"> : </td>
				<td>....</td>
				</tr>

				<tr>
				<td style="height:50px" class="pl-4"> Primary Color </td>	
				<td class="pl-3"> : </td>
				<td>.....</td>
				</tr>

				<tr>
				<td style="height:50px" class="pl-4"> Secondary Color </td>	
				<td class="pl-3"> : </td>
				<td>....</td>
				</tr>

				<tr>
				<td style="height:50px" class="pl-4"> Finisher </td>
				<td class="pl-3"> : </td>
				<td>.....</td>
				</tr>

				<tr>
				<td style="height:50px" class="pl-4"> Type </td>
				<td class="pl-3"> : </td>
				<td>....</td>
				</tr>

				<tr>
				<td style="height:50px" class="pl-4"> Gender </td>
				<td class="pl-3"> : </td>
				<td>.........</td>
				</tr>	

		</table>
	<br>

	</div><br>

	</div>
	<br>	

	<center>
	<a href="<?php echo e(route('create-post')); ?>"><h6>Create Your Own Kamen Rider</h6></a>
	</center>


<br><br>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\KULIAH\proyek_web\resources\views/posts.blade.php ENDPATH**/ ?>