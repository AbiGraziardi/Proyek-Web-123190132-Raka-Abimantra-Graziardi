<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
      <a class="navbar-brand" href="/">
        <img class="img-fluid" width="250" src="img/logo.png">
      </a>

      <div class="dropdown">
        <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">MENU </button>
      <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
        <a class="dropdown-item" href="/"><h6>Home</h6></a>
        <a class="dropdown-item" href="/about"><h6>Ultra Hero</h6></a>
        <a class="dropdown-item" href="/data-post"><h6>Character Creation</h6></a>
      </div>
      </div>

    </div>
  </nav><?php /**PATH C:\Users\user\Documents\KULIAH\proyek_web\resources\views/partials/navbar.blade.php ENDPATH**/ ?>