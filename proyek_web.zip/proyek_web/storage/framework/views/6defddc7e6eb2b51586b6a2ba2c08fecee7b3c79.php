<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

    <style>
	  ul#menu li {
  	   display:inline;
	  }

	  .zoom {
  	   transition: transform 0.2s; /* Animation */
	  }

	  .zoom:hover {
  	   transform: scale(1.13); /* (150% zoom - Note: if the zoom is too large, it will go outside of the viewport) */
	  }

    .background {
    width:45%;
    height: 100%;
    }

    .relative {
      position: relative;
      left: 300px;
    }
</style>
    <title>Project Web</title>
  </head>
<body>

  <?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div>
    <?php echo $__env->yieldContent('container'); ?>
</div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
</body>
</html>



<?php /**PATH C:\Users\user\Documents\KULIAH\proyek_web\resources\views/layouts/main.blade.php ENDPATH**/ ?>