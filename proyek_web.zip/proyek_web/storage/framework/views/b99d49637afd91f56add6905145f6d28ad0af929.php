

<?php $__env->startSection('container'); ?>
<br><br>
<div class="bg-dark background">
  <br>
  <h1 class="text-white relative">HEROES</h1>
  <br>
</div>
<br><br>


<div class="container-fluid">
  <center>
  <div>
      <ul id="menu">
  			<li style="padding: 20px;">
  					<img class="zoom" src="img/trigger.png">
  			</li>

  			<li style="padding: 20px;">
  					<img class="zoom" src="img/z.png">
  			</li>

  			<li style="padding: 20px;">
  					<img class="zoom" src="img/fuma.png">
  			</li>

        <li style="padding: 20px;">
            <img class="zoom" src="img/titas.png"
        </li>
  		</ul><br>

        <ul id="menu">
  			<li style="padding: 20px;">
  					<img class="zoom" src="img/taiga.png">
  			</li>

  			<li style="padding: 20px;">
  					<img class="zoom" src="img/grigio.png">
  			</li>

  			<li style="padding: 20px;">
  					<img class="zoom" src="img/blu.png">
  			</li>

        <li style="padding: 20px;">
            <img class="zoom" src="img/rosso.png"
        </li>
  		</ul><br>
  
  		<ul id="menu">
  			<li style="padding: 20px;">
  					<img class="zoom" src="img/geed.png">
  			</li>

  			<li style="padding: 20px;">
  					<img class="zoom" src="img/orb.png">
  			</li>

  			<li style="padding: 20px;">
  					<img class="zoom" src="img/x.png">
  			</li>

        <li style="padding: 20px;">
            <img class="zoom" src="img/victory.png"
        </li>
  		</ul><br>

  		<ul id="menu">
  			<li style="padding: 20px;">
  					<img class="zoom" src="img/ginga.png">
  			</li>

  			<li style="padding: 20px;">
  					<img class="zoom" src="img/zero.png">
  			</li>  	

  			<li style="padding: 20px;">
  					<img class="zoom" src="img/mebius.png">
  			</li> 

        <li style="padding: 20px;">
            <img class="zoom" src="img/max.png"
        </li> 
  		</ul><br>

  		<ul id="menu">
  			<li style="padding: 20px;">
  					<img class="zoom" src="img/nexus.png">
  			</li> 		

  			<li style="padding: 20px;">
  					<img class="zoom" src="img/cosmos.png">
  			</li> 	

  			<li style="padding: 20px;">
  					<img class="zoom" src="img/gaia.png">
  			</li> 	

        <li style="padding: 20px;">
            <img class="zoom" src="img/dyna.png"
        </li> 
  		</ul><br>

      <ul id="menu">
        <li style="padding: 20px;">
            <img class="zoom" src="img/tiga.png"
        </li>     

        <li style="padding: 20px;">
            <img class="zoom" src="img/80.png"
        </li>   

        <li style="padding: 20px;">
            <img class="zoom" src="img/leo.png"
        </li>   

        <li style="padding: 20px;">
            <img class="zoom" src="img/taro.png"
        </li> 
      </ul><br>

      <ul id="menu">
        <li style="padding: 20px;">
            <img class="zoom" src="img/ace.png"
        </li>     

        <li style="padding: 20px;">
            <img class="zoom" src="img/jack.png"
        </li>   

        <li style="padding: 20px;">
            <img class="zoom" src="img/ultraseven.png"
        </li>   

        <li style="padding: 20px;">
            <img class="zoom" src="img/ultraman.png"
        </li> 
      </ul><br>
 		
  	</div>
    </center>
</div>
<br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\KULIAH\proyek_web\resources\views/about.blade.php ENDPATH**/ ?>